import java.applet.Applet;
import java.awt.Button;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Loan extends Applet implements ActionListener{
	TextField loanAmt,Year,Interest,Result,Month;
	Button calculate;
	Label l1,l2,l3,l4,l5;
	public void init()
	{
		loanAmt=new TextField(15);
		loanAmt.setBounds(150, 50, 150, 20);
		Year = new TextField(15);
		Year.setBounds(150, 100, 150, 20);
		Interest = new TextField("11.6%");
		Interest.setBounds(150, 150, 150, 20);
		Interest.setEditable(false);
		calculate = new Button("Calculate Interest");
		calculate.setBounds(90, 200, 150, 20);
		Result = new TextField(15);
		Result.setBounds(150, 250, 150, 20);
		Month = new TextField(15);
		Month.setBounds(150, 300, 150, 20);
		calculate.addActionListener(this);
		l1 =new Label("Loan Amount");
		l1.setBounds(0, 50, 150, 20);
		l2=new Label("No of Years");
		l2.setBounds(0, 100, 150, 20);
		l3=new Label("Rate of Interest");
		l3.setBounds(0, 150, 150, 20);
		l4=new Label("Total Interest to be paid");
		l4.setBounds(0, 250, 150, 20);
		l5=new Label("Interest for one month");
		l5.setBounds(0,300,150,20);
		add(l1);
		add(loanAmt);
		add(l2);
		add(Year);
		add(l3);
		add(Interest);
		add(calculate);
		add(l4);
		add(Result);
		add(l5);
		add(Month);
		setSize(400,400);
		setLayout(null);
		//setBackground(Color.GRAY);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		String amt = loanAmt.getText();
		String nof = Year.getText();
		int p=Integer.parseInt(amt);
		int n=Integer.parseInt(nof);
		float si=0,m=0;
		si=(float) ((p*n*11.6)/100);
		m=(float)(si/(n*12));
		String result = String.valueOf(si);
		String permon = String.valueOf(m);
		Result.setText(result);
		Month.setText(permon);
	}

}
